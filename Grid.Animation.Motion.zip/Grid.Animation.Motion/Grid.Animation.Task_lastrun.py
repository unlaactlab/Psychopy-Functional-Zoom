﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v3.2.4),
    on January 20, 2023, at 09:34
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

from __future__ import absolute_import, division

from psychopy import locale_setup
from psychopy import prefs
from psychopy import sound, gui, visual, core, data, event, logging, clock
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle
import os  # handy system and path functions
import sys  # to get file system encoding

from psychopy.hardware import keyboard

# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)

# Store info about the experiment session
psychopyVersion = '3.2.4'
expName = 'VSD_EEG_motion.Grid_Animation'  # from the Builder filename that created this script
expInfo = {'participant': 'linda', 'amp_connected': False, 'debug': True}
dlg = gui.DlgFromDict(dictionary=expInfo, sortKeys=False, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName
expInfo['psychopyVersion'] = psychopyVersion

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + 'data' + os.sep + '%s_%s' % (expInfo['participant'], expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath='C:\\Psychopy Functional and zoom motion docs\\Grid.Animation.Motion\\Grid.Animation.Task_lastrun.py',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp
frameTolerance = 0.001  # how close to onset before 'same' frame

# Start Code - component code to be run before the window creation

# Setup the Window
win = visual.Window(
    size=[1440, 900], fullscr=True, screen=0, 
    winType='pyglet', allowGUI=False, allowStencil=False,
    monitor='testMonitor', color=[0.004,0.004,0.004], colorSpace='rgb',
    blendMode='avg', useFBO=True)
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess

# create a default keyboard (e.g. to check for escape)
defaultKeyboard = keyboard.Keyboard()

# Initialize components for Routine "Welcome_Screen"
Welcome_ScreenClock = core.Clock()
import time
import threading
if expInfo["amp_connected"]:
    import serial
else:
    from Scripts import dummy_serial as serial

# Set default values
Connected = True
PulseWidth = 0.01
imageScale = (1.5, 1.5)

# If debugging, only run each condition once.
if expInfo["debug"]:
    condition_repeats = 3
    thisExp.abort()
    stim_repeats = 3
else:
    condition_repeats = 12
    stim_repeats = 3

#def ReadThread(port):
#    while Connected:
#        if port.inWaiting() > 0:
#            print("0x%X"%ord port.read(1))
port = serial.Serial("COM3")

# Start the read thread thread 
#thread = threading.Thread(target=ReadThread, args=(port,))
#thread.start() 

# Set the port to an initial state
port.write([0x00])
time.sleep(PulseWidth)







#from psychopy import parallel
#par= parallel.PParallelInpOut32(address=0x278) #set parallel output
#par.setData(0)
#pser.setRTS(0)
#snd='smile'
#idx=0
#blklen=3 #number of sounds each block
#num_tri=75#number of trials for each sound
#duration=0.25#duration of sound
#devnum=5
#o=0
Interval=.5
#Natural=0
#Minimum=250
#Maximum= 350
Hi = visual.TextStim(win=win, name='Hi',
    text='You will be asked to look for a given picture. \n \nCount in your head how many times the given picture moves\n\nSit very still and relaxed.  \n \n',
    font='Arial',
    pos=[0,0.1], height=0.15, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);
End_Welcome_Screen = keyboard.Keyboard()

# Initialize components for Routine "Wait_Screen"
Wait_ScreenClock = core.Clock()
scene_background_prime = visual.ImageStim(
    win=win,
    name='scene_background_prime', 
    image='images/grid.objects.png', mask=None,
    ori=0, pos=(0, 0), size=1.0,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
Instructions_Text = visual.TextStim(win=win, name='Instructions_Text',
    text='Look for this picture....',
    font='Arial',
    pos=[0, 0.68], height=0.15, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-2.0);
End_Wait_Screen = keyboard.Keyboard()
TargetPres = visual.ImageStim(
    win=win,
    name='TargetPres', 
    image='sin', mask=None,
    ori=0, pos=(0, 0), size=1.0,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-4.0)
bg_p_2 = visual.ImageStim(
    win=win,
    name='bg_p_2', 
    image='images/grid.objects.png', mask=None,
    ori=0, pos=(0, 0), size=1.0,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-5.0)

# Initialize components for Routine "Stimulus_Blank_Screen"
Stimulus_Blank_ScreenClock = core.Clock()
import random
scene_background_isi = visual.ImageStim(
    win=win,
    name='scene_background_isi', 
    image='images/grid.objects.png', mask=None,
    ori=0, pos=(0, 0), size=1.0,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
diode_black = visual.Rect(
    win=win, name='diode_black',units='pix', 
    width=(45, 45)[0], height=(45, 45)[1],
    ori=0, pos=(-800, -340),
    lineWidth=1, lineColor=[-1.000,-1.000,-1.000], lineColorSpace='rgb',
    fillColor=[-1.000,-1.000,-1.000], fillColorSpace='rgb',
    opacity=1, depth=-2.0, interpolate=True)

# Initialize components for Routine "Stimulus_Display_Screen"
Stimulus_Display_ScreenClock = core.Clock()
#white = [0, 0, 0]
#black = [1, 1, 1]
#diode_color = white
#
#animationFile = None
#seconds_per_stim = 1
#
fps = int(win.fps())
print(f"fps = {fps}")
ObjectPresentation = visual.ImageStim(
    win=win,
    name='ObjectPresentation', 
    image='sin', mask=None,
    ori=0, pos=[0, 0], size=1.0,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
diode_white = visual.Rect(
    win=win, name='diode_white',units='pix', 
    width=(45, 45)[0], height=(45, 45)[1],
    ori=0, pos=(-800, -340),
    lineWidth=1, lineColor=[1.000,1.000,1.000], lineColorSpace='rgb',
    fillColor=[1.000,1.000,1.000], fillColorSpace='rgb',
    opacity=1, depth=-2.0, interpolate=True)
diode_black_2 = visual.Rect(
    win=win, name='diode_black_2',units='pix', 
    width=(45, 45)[0], height=(45, 45)[1],
    ori=0, pos=(-800, -340),
    lineWidth=1, lineColor=[-1.000,-1.000,-1.000], lineColorSpace='rgb',
    fillColor=[-1.000,-1.000,-1.000], fillColorSpace='rgb',
    opacity=1, depth=-3.0, interpolate=True)
ObjectPrePresentation = visual.ImageStim(
    win=win,
    name='ObjectPrePresentation', 
    image='images/grid.objects.png', mask=None,
    ori=0, pos=(0, 0), size=1.0,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-4.0)

# Initialize components for Routine "Break_Screen"
Break_ScreenClock = core.Clock()
SCREEN_WIDTH = float(win.size[0])
SCREEN_HEIGHT = float(win.size[1])
screen_ratio = SCREEN_HEIGHT / SCREEN_WIDTH 

break_image_1 = visual.ImageStim(
    win=win,
    name='break_image_1', 
    image='sin', mask=None,
    ori=0, pos=(-.5, 0), size=(.5, .5),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
break_image_2 = visual.ImageStim(
    win=win,
    name='break_image_2', 
    image='sin', mask=None,
    ori=0, pos=(.5,0), size=(.5, .5),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-2.0)
End_Break_Screen = keyboard.Keyboard()

# Initialize components for Routine "Salutation_Screen"
Salutation_ScreenClock = core.Clock()
bye = visual.TextStim(win=win, name='bye',
    text='Great, you are all done! \n \n',
    font='Arial',
    pos=[0, .5], height=0.12, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
key_resp_11 = keyboard.Keyboard()

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

# ------Prepare to start Routine "Welcome_Screen"-------
# update component parameters for each repeat
#i=0
#Nat={}
# Set Bit 0, Pin 2 of the Output(to Amp) connector 
#port.write([0x01]) 
time.sleep(PulseWidth) 
End_Welcome_Screen.keys = []
End_Welcome_Screen.rt = []
# keep track of which components have finished
Welcome_ScreenComponents = [Hi, End_Welcome_Screen]
for thisComponent in Welcome_ScreenComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
Welcome_ScreenClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1
continueRoutine = True

# -------Run Routine "Welcome_Screen"-------
while continueRoutine:
    # get current time
    t = Welcome_ScreenClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=Welcome_ScreenClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *Hi* updates
    if Hi.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        Hi.frameNStart = frameN  # exact frame index
        Hi.tStart = t  # local t and not account for scr refresh
        Hi.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(Hi, 'tStartRefresh')  # time at next scr refresh
        Hi.setAutoDraw(True)
    
    # *End_Welcome_Screen* updates
    waitOnFlip = False
    if End_Welcome_Screen.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        End_Welcome_Screen.frameNStart = frameN  # exact frame index
        End_Welcome_Screen.tStart = t  # local t and not account for scr refresh
        End_Welcome_Screen.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(End_Welcome_Screen, 'tStartRefresh')  # time at next scr refresh
        End_Welcome_Screen.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(End_Welcome_Screen.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(End_Welcome_Screen.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if End_Welcome_Screen.status == STARTED and not waitOnFlip:
        theseKeys = End_Welcome_Screen.getKeys(keyList=['y', 'n', 'left', 'right', 'space'], waitRelease=False)
        if len(theseKeys):
            theseKeys = theseKeys[0]  # at least one key was pressed
            
            # check for quit:
            if "escape" == theseKeys:
                endExpNow = True
            End_Welcome_Screen.keys = theseKeys.name  # just the last key pressed
            End_Welcome_Screen.rt = theseKeys.rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Welcome_ScreenComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Welcome_Screen"-------
for thisComponent in Welcome_ScreenComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)


# Reset Bit 0, Pin 2 of the Output(to Amp) connector
port.write([0x00]) 
#time.sleep(PulseWidth) 

#pser=serial.Serial(0)
#init serial output
#print order[1:20,:]
thisExp.addData('Hi.started', Hi.tStartRefresh)
thisExp.addData('Hi.stopped', Hi.tStopRefresh)
# check responses
if End_Welcome_Screen.keys in ['', [], None]:  # No response was made
    End_Welcome_Screen.keys = None
thisExp.addData('End_Welcome_Screen.keys',End_Welcome_Screen.keys)
if End_Welcome_Screen.keys != None:  # we had a response
    thisExp.addData('End_Welcome_Screen.rt', End_Welcome_Screen.rt)
thisExp.addData('End_Welcome_Screen.started', End_Welcome_Screen.tStartRefresh)
thisExp.addData('End_Welcome_Screen.stopped', End_Welcome_Screen.tStopRefresh)
thisExp.nextEntry()
# the Routine "Welcome_Screen" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
Trials_Loop = data.TrialHandler(nReps=1, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('Parameters/Target.csv'),
    seed=None, name='Trials_Loop')
thisExp.addLoop(Trials_Loop)  # add the loop to the experiment
thisTrials_Loop = Trials_Loop.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisTrials_Loop.rgb)
if thisTrials_Loop != None:
    for paramName in thisTrials_Loop:
        exec('{} = thisTrials_Loop[paramName]'.format(paramName))

for thisTrials_Loop in Trials_Loop:
    currentLoop = Trials_Loop
    # abbreviate parameter names if possible (e.g. rgb = thisTrials_Loop.rgb)
    if thisTrials_Loop != None:
        for paramName in thisTrials_Loop:
            exec('{} = thisTrials_Loop[paramName]'.format(paramName))
    
    # set up handler to look after randomisation of conditions etc
    targetScreen = data.TrialHandler(nReps=stim_repeats, method='sequential', 
        extraInfo=expInfo, originPath=-1,
        trialList=[None],
        seed=None, name='targetScreen')
    thisExp.addLoop(targetScreen)  # add the loop to the experiment
    thisTargetScreen = targetScreen.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTargetScreen.rgb)
    if thisTargetScreen != None:
        for paramName in thisTargetScreen:
            exec('{} = thisTargetScreen[paramName]'.format(paramName))
    
    for thisTargetScreen in targetScreen:
        currentLoop = targetScreen
        # abbreviate parameter names if possible (e.g. rgb = thisTargetScreen.rgb)
        if thisTargetScreen != None:
            for paramName in thisTargetScreen:
                exec('{} = thisTargetScreen[paramName]'.format(paramName))
        
        # ------Prepare to start Routine "Wait_Screen"-------
        # update component parameters for each repeat
        Targ = TargetTrigger
        
        scene_background_prime.setSize(imageScale)
        End_Wait_Screen.keys = []
        End_Wait_Screen.rt = []
        TargetPres.setSize(imageScale)
        bg_p_2.setSize(imageScale)
        # keep track of which components have finished
        Wait_ScreenComponents = [scene_background_prime, Instructions_Text, End_Wait_Screen, TargetPres, bg_p_2]
        for thisComponent in Wait_ScreenComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        Wait_ScreenClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        continueRoutine = True
        
        # -------Run Routine "Wait_Screen"-------
        while continueRoutine:
            # get current time
            t = Wait_ScreenClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=Wait_ScreenClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *scene_background_prime* updates
            if scene_background_prime.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                scene_background_prime.frameNStart = frameN  # exact frame index
                scene_background_prime.tStart = t  # local t and not account for scr refresh
                scene_background_prime.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(scene_background_prime, 'tStartRefresh')  # time at next scr refresh
                scene_background_prime.setAutoDraw(True)
            if scene_background_prime.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > scene_background_prime.tStartRefresh + 1.0-frameTolerance:
                    # keep track of stop time/frame for later
                    scene_background_prime.tStop = t  # not accounting for scr refresh
                    scene_background_prime.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(scene_background_prime, 'tStopRefresh')  # time at next scr refresh
                    scene_background_prime.setAutoDraw(False)
            
            # *Instructions_Text* updates
            if Instructions_Text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Instructions_Text.frameNStart = frameN  # exact frame index
                Instructions_Text.tStart = t  # local t and not account for scr refresh
                Instructions_Text.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Instructions_Text, 'tStartRefresh')  # time at next scr refresh
                Instructions_Text.setAutoDraw(True)
            
            # *End_Wait_Screen* updates
            waitOnFlip = False
            if End_Wait_Screen.status == NOT_STARTED and tThisFlip >= 1.0-frameTolerance:
                # keep track of start time/frame for later
                End_Wait_Screen.frameNStart = frameN  # exact frame index
                End_Wait_Screen.tStart = t  # local t and not account for scr refresh
                End_Wait_Screen.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(End_Wait_Screen, 'tStartRefresh')  # time at next scr refresh
                End_Wait_Screen.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(End_Wait_Screen.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(End_Wait_Screen.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if End_Wait_Screen.status == STARTED and not waitOnFlip:
                theseKeys = End_Wait_Screen.getKeys(keyList=['left', 'right', 'space'], waitRelease=False)
                if len(theseKeys):
                    theseKeys = theseKeys[0]  # at least one key was pressed
                    
                    # check for quit:
                    if "escape" == theseKeys:
                        endExpNow = True
                    End_Wait_Screen.keys = theseKeys.name  # just the last key pressed
                    End_Wait_Screen.rt = theseKeys.rt
                    # a response ends the routine
                    continueRoutine = False
            
            # *TargetPres* updates
            if TargetPres.status == NOT_STARTED and frameN >= 60:
                # keep track of start time/frame for later
                TargetPres.frameNStart = frameN  # exact frame index
                TargetPres.tStart = t  # local t and not account for scr refresh
                TargetPres.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(TargetPres, 'tStartRefresh')  # time at next scr refresh
                TargetPres.setAutoDraw(True)
            if TargetPres.status == STARTED:
                if frameN >= (TargetPres.frameNStart + 50):
                    # keep track of stop time/frame for later
                    TargetPres.tStop = t  # not accounting for scr refresh
                    TargetPres.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(TargetPres, 'tStopRefresh')  # time at next scr refresh
                    TargetPres.setAutoDraw(False)
            if TargetPres.status == STARTED:  # only update if drawing
                TargetPres.setImage(f"images/{TargetObject}/{TargetObject}{frameN-60:02}.png", log=False)
            
            # *bg_p_2* updates
            if bg_p_2.status == NOT_STARTED and frameN >= 110:
                # keep track of start time/frame for later
                bg_p_2.frameNStart = frameN  # exact frame index
                bg_p_2.tStart = t  # local t and not account for scr refresh
                bg_p_2.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(bg_p_2, 'tStartRefresh')  # time at next scr refresh
                bg_p_2.setAutoDraw(True)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in Wait_ScreenComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "Wait_Screen"-------
        for thisComponent in Wait_ScreenComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        targetScreen.addData('scene_background_prime.started', scene_background_prime.tStartRefresh)
        targetScreen.addData('scene_background_prime.stopped', scene_background_prime.tStopRefresh)
        targetScreen.addData('Instructions_Text.started', Instructions_Text.tStartRefresh)
        targetScreen.addData('Instructions_Text.stopped', Instructions_Text.tStopRefresh)
        # check responses
        if End_Wait_Screen.keys in ['', [], None]:  # No response was made
            End_Wait_Screen.keys = None
        targetScreen.addData('End_Wait_Screen.keys',End_Wait_Screen.keys)
        if End_Wait_Screen.keys != None:  # we had a response
            targetScreen.addData('End_Wait_Screen.rt', End_Wait_Screen.rt)
        targetScreen.addData('End_Wait_Screen.started', End_Wait_Screen.tStartRefresh)
        targetScreen.addData('End_Wait_Screen.stopped', End_Wait_Screen.tStopRefresh)
        targetScreen.addData('TargetPres.started', TargetPres.tStartRefresh)
        targetScreen.addData('TargetPres.stopped', TargetPres.tStopRefresh)
        targetScreen.addData('bg_p_2.started', bg_p_2.tStartRefresh)
        targetScreen.addData('bg_p_2.stopped', bg_p_2.tStopRefresh)
        # the Routine "Wait_Screen" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
    # completed stim_repeats repeats of 'targetScreen'
    
    
    # set up handler to look after randomisation of conditions etc
    Stimuli_Loop = data.TrialHandler(nReps=condition_repeats, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions('Parameters/Stimuli.csv'),
        seed=None, name='Stimuli_Loop')
    thisExp.addLoop(Stimuli_Loop)  # add the loop to the experiment
    thisStimulus_Loop = Stimuli_Loop.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisStimulus_Loop.rgb)
    if thisStimulus_Loop != None:
        for paramName in thisStimulus_Loop:
            exec('{} = thisStimulus_Loop[paramName]'.format(paramName))
    
    for thisStimulus_Loop in Stimuli_Loop:
        currentLoop = Stimuli_Loop
        # abbreviate parameter names if possible (e.g. rgb = thisStimulus_Loop.rgb)
        if thisStimulus_Loop != None:
            for paramName in thisStimulus_Loop:
                exec('{} = thisStimulus_Loop[paramName]'.format(paramName))
        
        # ------Prepare to start Routine "Stimulus_Blank_Screen"-------
        # update component parameters for each repeat
        if Targ==Trigger: 
             port.write([int(Trigger+32)]) 
        else: 
             port.write([int(Trigger)]) 
        time.sleep(PulseWidth)
        
        #randT=random.random()-0.5
        randT=random.randint(13,18)/100 + .004
        print(randT)
        #targeted 175ms ISI
        prevFrameTime = 0
        
        scene_background_isi.setSize(imageScale)
        # keep track of which components have finished
        Stimulus_Blank_ScreenComponents = [scene_background_isi, diode_black]
        for thisComponent in Stimulus_Blank_ScreenComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        Stimulus_Blank_ScreenClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        continueRoutine = True
        
        # -------Run Routine "Stimulus_Blank_Screen"-------
        while continueRoutine:
            # get current time
            t = Stimulus_Blank_ScreenClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=Stimulus_Blank_ScreenClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *scene_background_isi* updates
            if scene_background_isi.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                scene_background_isi.frameNStart = frameN  # exact frame index
                scene_background_isi.tStart = t  # local t and not account for scr refresh
                scene_background_isi.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(scene_background_isi, 'tStartRefresh')  # time at next scr refresh
                scene_background_isi.setAutoDraw(True)
            if scene_background_isi.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > scene_background_isi.tStartRefresh + randT-frameTolerance:
                    # keep track of stop time/frame for later
                    scene_background_isi.tStop = t  # not accounting for scr refresh
                    scene_background_isi.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(scene_background_isi, 'tStopRefresh')  # time at next scr refresh
                    scene_background_isi.setAutoDraw(False)
            
            # *diode_black* updates
            if diode_black.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                diode_black.frameNStart = frameN  # exact frame index
                diode_black.tStart = t  # local t and not account for scr refresh
                diode_black.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(diode_black, 'tStartRefresh')  # time at next scr refresh
                diode_black.setAutoDraw(True)
            if diode_black.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > diode_black.tStartRefresh + randT-frameTolerance:
                    # keep track of stop time/frame for later
                    diode_black.tStop = t  # not accounting for scr refresh
                    diode_black.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(diode_black, 'tStopRefresh')  # time at next scr refresh
                    diode_black.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in Stimulus_Blank_ScreenComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "Stimulus_Blank_Screen"-------
        for thisComponent in Stimulus_Blank_ScreenComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        Stimuli_Loop.addData('scene_background_isi.started', scene_background_isi.tStartRefresh)
        Stimuli_Loop.addData('scene_background_isi.stopped', scene_background_isi.tStopRefresh)
        Stimuli_Loop.addData('diode_black.started', diode_black.tStartRefresh)
        Stimuli_Loop.addData('diode_black.stopped', diode_black.tStopRefresh)
        # the Routine "Stimulus_Blank_Screen" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # ------Prepare to start Routine "Stimulus_Display_Screen"-------
        # update component parameters for each repeat
        if Targ==Trigger: 
             port.write([int(Trigger+32)]) 
        else: 
             port.write([int(Trigger)]) 
        time.sleep(PulseWidth)
        
        #frames_per_stim = fps * seconds_per_stim
        #frameImageNumbers = list(range(300, 0, -frames_per_stim))
        #prevFrameTime = 0
        #animationFile = f"{ObjectPath}/{Object}.000.png"
        
        ObjectPresentation.setSize(imageScale)
        ObjectPrePresentation.setSize(imageScale)
        # keep track of which components have finished
        Stimulus_Display_ScreenComponents = [ObjectPresentation, diode_white, diode_black_2, ObjectPrePresentation]
        for thisComponent in Stimulus_Display_ScreenComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        Stimulus_Display_ScreenClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        continueRoutine = True
        
        # -------Run Routine "Stimulus_Display_Screen"-------
        while continueRoutine:
            # get current time
            t = Stimulus_Display_ScreenClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=Stimulus_Display_ScreenClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            #if frameN % 4 == 1:
            #    diode_color = white
            #else:
            #    diode_color = black
            #print(frameN, diode_color)
            
            #print(f"time = {t}")
            #print(f"frame time difference = {t - prevFrameTime}")
            #prevFrameTime = t
            
            #thisImageNumber = frameImageNumbers.pop()
            #animationFile = f"{ObjectPath}/{Object}.{thisImageNumber:03}.png"
            
            # *ObjectPresentation* updates
            if ObjectPresentation.status == NOT_STARTED and frameN >= 1:
                # keep track of start time/frame for later
                ObjectPresentation.frameNStart = frameN  # exact frame index
                ObjectPresentation.tStart = t  # local t and not account for scr refresh
                ObjectPresentation.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(ObjectPresentation, 'tStartRefresh')  # time at next scr refresh
                ObjectPresentation.setAutoDraw(True)
            if ObjectPresentation.status == STARTED:
                if frameN >= (ObjectPresentation.frameNStart + 48):
                    # keep track of stop time/frame for later
                    ObjectPresentation.tStop = t  # not accounting for scr refresh
                    ObjectPresentation.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(ObjectPresentation, 'tStopRefresh')  # time at next scr refresh
                    ObjectPresentation.setAutoDraw(False)
            if ObjectPresentation.status == STARTED:  # only update if drawing
                ObjectPresentation.setImage(f"{ObjectPath}/{Object}{frameN:02}.png", log=False)
            
            # *diode_white* updates
            if diode_white.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                diode_white.frameNStart = frameN  # exact frame index
                diode_white.tStart = t  # local t and not account for scr refresh
                diode_white.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(diode_white, 'tStartRefresh')  # time at next scr refresh
                diode_white.setAutoDraw(True)
            if diode_white.status == STARTED:
                if frameN >= (diode_white.frameNStart + 1):
                    # keep track of stop time/frame for later
                    diode_white.tStop = t  # not accounting for scr refresh
                    diode_white.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(diode_white, 'tStopRefresh')  # time at next scr refresh
                    diode_white.setAutoDraw(False)
            
            # *diode_black_2* updates
            if diode_black_2.status == NOT_STARTED and frameN >= 2:
                # keep track of start time/frame for later
                diode_black_2.frameNStart = frameN  # exact frame index
                diode_black_2.tStart = t  # local t and not account for scr refresh
                diode_black_2.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(diode_black_2, 'tStartRefresh')  # time at next scr refresh
                diode_black_2.setAutoDraw(True)
            if diode_black_2.status == STARTED:
                if frameN >= (diode_black_2.frameNStart + 47):
                    # keep track of stop time/frame for later
                    diode_black_2.tStop = t  # not accounting for scr refresh
                    diode_black_2.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(diode_black_2, 'tStopRefresh')  # time at next scr refresh
                    diode_black_2.setAutoDraw(False)
            
            # *ObjectPrePresentation* updates
            if ObjectPrePresentation.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                ObjectPrePresentation.frameNStart = frameN  # exact frame index
                ObjectPrePresentation.tStart = t  # local t and not account for scr refresh
                ObjectPrePresentation.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(ObjectPrePresentation, 'tStartRefresh')  # time at next scr refresh
                ObjectPrePresentation.setAutoDraw(True)
            if ObjectPrePresentation.status == STARTED:
                if frameN >= (ObjectPrePresentation.frameNStart + 1):
                    # keep track of stop time/frame for later
                    ObjectPrePresentation.tStop = t  # not accounting for scr refresh
                    ObjectPrePresentation.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(ObjectPrePresentation, 'tStopRefresh')  # time at next scr refresh
                    ObjectPrePresentation.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in Stimulus_Display_ScreenComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "Stimulus_Display_Screen"-------
        for thisComponent in Stimulus_Display_ScreenComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # Reset Bit 0, Pin 2 of the Output(to Amp) connector
        port.write([0x00]) 
        time.sleep(PulseWidth)
        
        #nextTrial = trials.getFutureTrial(1)
        #ObjectPresentation.image = nextTrial['ObjectPresentation']
        #print(ObjectPresentation.image)
        
        print(f"time = {t}")
        print(f"frame time difference = {t - prevFrameTime}")
        prevFrameTime = t
        Stimuli_Loop.addData('ObjectPresentation.started', ObjectPresentation.tStartRefresh)
        Stimuli_Loop.addData('ObjectPresentation.stopped', ObjectPresentation.tStopRefresh)
        Stimuli_Loop.addData('diode_white.started', diode_white.tStartRefresh)
        Stimuli_Loop.addData('diode_white.stopped', diode_white.tStopRefresh)
        Stimuli_Loop.addData('diode_black_2.started', diode_black_2.tStartRefresh)
        Stimuli_Loop.addData('diode_black_2.stopped', diode_black_2.tStopRefresh)
        Stimuli_Loop.addData('ObjectPrePresentation.started', ObjectPrePresentation.tStartRefresh)
        Stimuli_Loop.addData('ObjectPrePresentation.stopped', ObjectPrePresentation.tStopRefresh)
        # the Routine "Stimulus_Display_Screen" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
    # completed condition_repeats repeats of 'Stimuli_Loop'
    
    
    # set up handler to look after randomisation of conditions etc
    Break_Loop = data.TrialHandler(nReps=1, method='sequential', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions('Parameters/Break.csv', selection=[Trials_Loop.thisN]),
        seed=None, name='Break_Loop')
    thisExp.addLoop(Break_Loop)  # add the loop to the experiment
    thisBreak_Loop = Break_Loop.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisBreak_Loop.rgb)
    if thisBreak_Loop != None:
        for paramName in thisBreak_Loop:
            exec('{} = thisBreak_Loop[paramName]'.format(paramName))
    
    for thisBreak_Loop in Break_Loop:
        currentLoop = Break_Loop
        # abbreviate parameter names if possible (e.g. rgb = thisBreak_Loop.rgb)
        if thisBreak_Loop != None:
            for paramName in thisBreak_Loop:
                exec('{} = thisBreak_Loop[paramName]'.format(paramName))
        
        # ------Prepare to start Routine "Break_Screen"-------
        # update component parameters for each repeat
        break_image_width = BreakImageSizeX * BreakImageScale * screen_ratio
        break_image_height = BreakImageSizeY * BreakImageScale
        
        break_image_1.setImage(BreakImagePath_1)
        break_image_2.setImage(BreakImagePath_2)
        End_Break_Screen.keys = []
        End_Break_Screen.rt = []
        # keep track of which components have finished
        Break_ScreenComponents = [break_image_1, break_image_2, End_Break_Screen]
        for thisComponent in Break_ScreenComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        Break_ScreenClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        continueRoutine = True
        
        # -------Run Routine "Break_Screen"-------
        while continueRoutine:
            # get current time
            t = Break_ScreenClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=Break_ScreenClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *break_image_1* updates
            if break_image_1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                break_image_1.frameNStart = frameN  # exact frame index
                break_image_1.tStart = t  # local t and not account for scr refresh
                break_image_1.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(break_image_1, 'tStartRefresh')  # time at next scr refresh
                break_image_1.setAutoDraw(True)
            
            # *break_image_2* updates
            if break_image_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                break_image_2.frameNStart = frameN  # exact frame index
                break_image_2.tStart = t  # local t and not account for scr refresh
                break_image_2.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(break_image_2, 'tStartRefresh')  # time at next scr refresh
                break_image_2.setAutoDraw(True)
            
            # *End_Break_Screen* updates
            waitOnFlip = False
            if End_Break_Screen.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                End_Break_Screen.frameNStart = frameN  # exact frame index
                End_Break_Screen.tStart = t  # local t and not account for scr refresh
                End_Break_Screen.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(End_Break_Screen, 'tStartRefresh')  # time at next scr refresh
                End_Break_Screen.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(End_Break_Screen.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(End_Break_Screen.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if End_Break_Screen.status == STARTED and not waitOnFlip:
                theseKeys = End_Break_Screen.getKeys(keyList=['y', 'n', 'left', 'right', 'space'], waitRelease=False)
                if len(theseKeys):
                    theseKeys = theseKeys[0]  # at least one key was pressed
                    
                    # check for quit:
                    if "escape" == theseKeys:
                        endExpNow = True
                    End_Break_Screen.keys = theseKeys.name  # just the last key pressed
                    End_Break_Screen.rt = theseKeys.rt
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in Break_ScreenComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "Break_Screen"-------
        for thisComponent in Break_ScreenComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        Break_Loop.addData('break_image_1.started', break_image_1.tStartRefresh)
        Break_Loop.addData('break_image_1.stopped', break_image_1.tStopRefresh)
        Break_Loop.addData('break_image_2.started', break_image_2.tStartRefresh)
        Break_Loop.addData('break_image_2.stopped', break_image_2.tStopRefresh)
        # check responses
        if End_Break_Screen.keys in ['', [], None]:  # No response was made
            End_Break_Screen.keys = None
        Break_Loop.addData('End_Break_Screen.keys',End_Break_Screen.keys)
        if End_Break_Screen.keys != None:  # we had a response
            Break_Loop.addData('End_Break_Screen.rt', End_Break_Screen.rt)
        Break_Loop.addData('End_Break_Screen.started', End_Break_Screen.tStartRefresh)
        Break_Loop.addData('End_Break_Screen.stopped', End_Break_Screen.tStopRefresh)
        # the Routine "Break_Screen" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
    # completed 1 repeats of 'Break_Loop'
    
    thisExp.nextEntry()
    
# completed 1 repeats of 'Trials_Loop'


# ------Prepare to start Routine "Salutation_Screen"-------
# update component parameters for each repeat
key_resp_11.keys = []
key_resp_11.rt = []
# keep track of which components have finished
Salutation_ScreenComponents = [bye, key_resp_11]
for thisComponent in Salutation_ScreenComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
Salutation_ScreenClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1
continueRoutine = True

# -------Run Routine "Salutation_Screen"-------
while continueRoutine:
    # get current time
    t = Salutation_ScreenClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=Salutation_ScreenClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *bye* updates
    if bye.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        bye.frameNStart = frameN  # exact frame index
        bye.tStart = t  # local t and not account for scr refresh
        bye.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(bye, 'tStartRefresh')  # time at next scr refresh
        bye.setAutoDraw(True)
    
    # *key_resp_11* updates
    waitOnFlip = False
    if key_resp_11.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        key_resp_11.frameNStart = frameN  # exact frame index
        key_resp_11.tStart = t  # local t and not account for scr refresh
        key_resp_11.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(key_resp_11, 'tStartRefresh')  # time at next scr refresh
        key_resp_11.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(key_resp_11.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(key_resp_11.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if key_resp_11.status == STARTED and not waitOnFlip:
        theseKeys = key_resp_11.getKeys(keyList=['left', 'right', 'space'], waitRelease=False)
        if len(theseKeys):
            theseKeys = theseKeys[0]  # at least one key was pressed
            
            # check for quit:
            if "escape" == theseKeys:
                endExpNow = True
            key_resp_11.keys = theseKeys.name  # just the last key pressed
            key_resp_11.rt = theseKeys.rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Salutation_ScreenComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Salutation_Screen"-------
for thisComponent in Salutation_ScreenComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('bye.started', bye.tStartRefresh)
thisExp.addData('bye.stopped', bye.tStopRefresh)
# check responses
if key_resp_11.keys in ['', [], None]:  # No response was made
    key_resp_11.keys = None
thisExp.addData('key_resp_11.keys',key_resp_11.keys)
if key_resp_11.keys != None:  # we had a response
    thisExp.addData('key_resp_11.rt', key_resp_11.rt)
thisExp.addData('key_resp_11.started', key_resp_11.tStartRefresh)
thisExp.addData('key_resp_11.stopped', key_resp_11.tStopRefresh)
thisExp.nextEntry()
# the Routine "Salutation_Screen" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()
# Reset the port to its default state 
port.write([0xFF]) 
#time.sleep(PulseWidth)

# Terminate the read thread
#Connected = False 
#thread.join(1.0) 


 # Close the serial port 
port.close()


#pser.close()

# Flip one final time so any remaining win.callOnFlip() 
# and win.timeOnFlip() tasks get executed before quitting
win.flip()

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()
